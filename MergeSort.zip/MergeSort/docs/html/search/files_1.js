var searchData=
[
  ['testdoduje_2ecpp_0',['testdoduje.cpp',['../testdoduje_8cpp.html',1,'']]],
  ['testduplikat_2ecpp_1',['testduplikat.cpp',['../testduplikat_8cpp.html',1,'']]],
  ['testjeden_2ecpp_2',['testjeden.cpp',['../testjeden_8cpp.html',1,'']]],
  ['testlosowy_2ecpp_3',['testlosowy.cpp',['../testlosowy_8cpp.html',1,'']]],
  ['testodwrotny_2ecpp_4',['testodwrotny.cpp',['../testodwrotny_8cpp.html',1,'']]],
  ['testpusty_2ecpp_5',['testpusty.cpp',['../testpusty_8cpp.html',1,'']]],
  ['testsortowania_2ecpp_6',['Testsortowania.cpp',['../_testsortowania_8cpp.html',1,'']]],
  ['testujemny_2ecpp_7',['testujemny.cpp',['../testujemny_8cpp.html',1,'']]],
  ['testwiekszy_2ecpp_8',['testwiekszy.cpp',['../testwiekszy_8cpp.html',1,'']]]
];

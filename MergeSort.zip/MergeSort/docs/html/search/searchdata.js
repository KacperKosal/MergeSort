var indexSectionsWithContent =
{
  0: "lmst",
  1: "m",
  2: "mt",
  3: "mst",
  4: "lt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Strony"
};


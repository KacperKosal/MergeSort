var searchData=
[
  ['testów_0',['Lista testów',['../test.html',1,'']]],
  ['test_1',['TEST',['../testdoduje_8cpp.html#abd364edbfed8dbdf73454079ddb1b753',1,'TEST(MergeSortTests, NegativeAndPositiveNumbers):&#160;testdoduje.cpp'],['../testduplikat_8cpp.html#a49ca750662b44d9a46523f7e91d97d20',1,'TEST(MergeSortTests, DuplicatesArray):&#160;testduplikat.cpp'],['../testjeden_8cpp.html#a8f5b91e8385d5e5507ccd5566077ce4f',1,'TEST(MergeSortTests, SingleElementArray):&#160;testjeden.cpp'],['../testlosowy_8cpp.html#ae634a5443c1651532461b0ebe4380d61',1,'TEST(MergeSortTests, RandomArray):&#160;testlosowy.cpp'],['../testodwrotny_8cpp.html#a6e0994f44ed4eabb5aba7b552f24372c',1,'TEST(MergeSortTests, ReversedArray):&#160;testodwrotny.cpp'],['../testpusty_8cpp.html#a087bd2fb35f6d6ff4627bed20334dee6',1,'TEST(MergeSortTests, EmptyArray):&#160;testpusty.cpp'],['../_testsortowania_8cpp.html#a5d4488dd95ea7ba5098c810cb3176d0e',1,'TEST(MergeSortTests, SortedArray):&#160;Testsortowania.cpp'],['../testujemny_8cpp.html#a90d1421780f84a8c9aa05c7c8207d79e',1,'TEST(MergeSortTests, NegativeNumbers):&#160;testujemny.cpp'],['../testwiekszy_8cpp.html#ab560655c7724de98bc956634942da06e',1,'TEST(MergeSortTests, LargeArray):&#160;testwiekszy.cpp']]],
  ['testdoduje_2ecpp_2',['testdoduje.cpp',['../testdoduje_8cpp.html',1,'']]],
  ['testduplikat_2ecpp_3',['testduplikat.cpp',['../testduplikat_8cpp.html',1,'']]],
  ['testjeden_2ecpp_4',['testjeden.cpp',['../testjeden_8cpp.html',1,'']]],
  ['testlosowy_2ecpp_5',['testlosowy.cpp',['../testlosowy_8cpp.html',1,'']]],
  ['testodwrotny_2ecpp_6',['testodwrotny.cpp',['../testodwrotny_8cpp.html',1,'']]],
  ['testpusty_2ecpp_7',['testpusty.cpp',['../testpusty_8cpp.html',1,'']]],
  ['testsortowania_2ecpp_8',['Testsortowania.cpp',['../_testsortowania_8cpp.html',1,'']]],
  ['testujemny_2ecpp_9',['testujemny.cpp',['../testujemny_8cpp.html',1,'']]],
  ['testwiekszy_2ecpp_10',['testwiekszy.cpp',['../testwiekszy_8cpp.html',1,'']]]
];
